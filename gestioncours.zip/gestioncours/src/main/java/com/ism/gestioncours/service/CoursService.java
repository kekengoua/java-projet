package com.ism.gestioncours.service;

import com.ism.gestioncours.entities.Cours;
import com.ism.gestioncours.repository.CoursRepository;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class CoursService {
    private CoursRepository coursRepository;

    public CoursService(CoursRepository coursRepository) {
        this.coursRepository = coursRepository;
    }

    public void createCours(LocalDate date, LocalTime heureDb, LocalTime heureFin, int professeurId, int moduleId) {
        Cours cours = new Cours(date, heureDb, heureFin, professeurId, moduleId);
        coursRepository.save(cours);
    }

    public List<Cours> listAllCours() {
        return coursRepository.findAll();
    }

    public List<Cours> listCoursByModuleAndProfesseur(int moduleId, int professeurId) {
        return coursRepository.findByModuleAndProfesseur(moduleId, professeurId);
    }
}
