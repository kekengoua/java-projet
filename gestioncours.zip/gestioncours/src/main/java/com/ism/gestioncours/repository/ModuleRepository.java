package com.ism.gestioncours.repository;

import com.ism.gestioncours.entities.Module;
import java.util.List;

public interface ModuleRepository {
    void save(Module module);
    List<Module> findAll();
}
