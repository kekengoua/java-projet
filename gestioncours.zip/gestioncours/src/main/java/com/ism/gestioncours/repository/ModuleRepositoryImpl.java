package com.ism.gestioncours.repository;

import com.ism.gestioncours.entities.Module;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ModuleRepositoryImpl implements ModuleRepository {
    private Connection connection;

    public ModuleRepositoryImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void save(Module module) {
        String sql = "INSERT INTO modules (nom) VALUES (?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, module.getNom());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public List<Module> findAll() {
        List<Module> modules = new ArrayList<>();
        String sql = "SELECT * FROM modules";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Module module = new Module(rs.getInt("id"), rs.getString("nom"));
                modules.add(module);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return modules;
    }
}
