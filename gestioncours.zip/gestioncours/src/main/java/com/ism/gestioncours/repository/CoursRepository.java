package com.ism.gestioncours.repository;

import com.ism.gestioncours.entities.Cours;
import java.util.List;

public interface CoursRepository {
    void save(Cours cours);
    List<Cours> findAll();
    List<Cours> findByModuleAndProfesseur(int moduleId, int professeurId);
}
