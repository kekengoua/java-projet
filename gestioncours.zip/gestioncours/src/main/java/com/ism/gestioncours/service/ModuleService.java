package com.ism.gestioncours.service;

import com.ism.gestioncours.entities.Module;
import com.ism.gestioncours.repository.ModuleRepository;
import java.util.List;

public class ModuleService {
    private ModuleRepository moduleRepository;

    public ModuleService(ModuleRepository moduleRepository) {
        this.moduleRepository = moduleRepository;
    }

    public void addModule(String nom) {
        Module module = new Module(nom);
        moduleRepository.save(module);
    }

    public List<Module> listModules() {
        return moduleRepository.findAll();
    }
}
