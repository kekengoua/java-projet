package com.ism.gestioncours.repository;

import com.ism.gestioncours.entities.Cours;
import com.ism.gestioncours.entities.Professeur;
import com.ism.gestioncours.entities.Module;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CoursRepositoryImpl implements CoursRepository {
    private Connection connection;

    public CoursRepositoryImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void save(Cours cours) {
        String sql = "INSERT INTO cours (date, heureDb, heureFin, professeur_id, module_id) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setDate(1, Date.valueOf(cours.getDate()));
            pstmt.setTime(2, Time.valueOf(cours.getHeureDb()));
            pstmt.setTime(3, Time.valueOf(cours.getHeureFin()));
            pstmt.setInt(4, cours.getProfesseur().getId());
            pstmt.setInt(5, cours.getModule().getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public List<Cours> findAll() {
        List<Cours> coursList = new ArrayList<>();
        String sql = "SELECT c.id, c.date, c.heureDb, c.heureFin, p.id AS professeur_id, p.nom AS professeur_nom, p.prenom AS professeur_prenom, p.tel AS professeur_tel, m.id AS module_id, m.nom AS module_nom FROM cours c JOIN professeurs p ON c.professeur_id = p.id JOIN modules m ON c.module_id = m.id";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Professeur professeur = new Professeur(rs.getInt("professeur_id"), rs.getString("professeur_nom"), rs.getString("professeur_prenom"), rs.getString("professeur_tel"));
                Module module = new Module(rs.getInt("module_id"), rs.getString("module_nom"));
                Cours cours = new Cours(rs.getInt("id"), rs.getDate("date").toLocalDate(), rs.getTime("heureDb").toLocalTime(), rs.getTime("heureFin").toLocalTime(), professeur, module);
                coursList.add(cours);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return coursList;
    }

    @Override
    public List<Cours> findByModuleAndProfesseur(int moduleId, int professeurId) {
        List<Cours> coursList = new ArrayList<>();
        String sql = "SELECT c.id, c.date, c.heureDb, c.heureFin, p.id AS professeur_id, p.nom AS professeur_nom, p.prenom AS professeur_prenom, p.tel AS professeur_tel, m.id AS module_id, m.nom AS module_nom FROM cours c JOIN professeurs p ON c.professeur_id = p.id JOIN modules m ON c.module_id = m.id WHERE c.module_id = ? AND c.professeur_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, moduleId);
            pstmt.setInt(2, professeurId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Professeur professeur = new Professeur(rs.getInt("professeur_id"), rs.getString("professeur_nom"), rs.getString("professeur_prenom"), rs.getString("professeur_tel"));
                Module module = new Module(rs.getInt("module_id"), rs.getString("module_nom"));
                Cours cours = new Cours(rs.getInt("id"), rs.getDate("date").toLocalDate(), rs.getTime("heure
