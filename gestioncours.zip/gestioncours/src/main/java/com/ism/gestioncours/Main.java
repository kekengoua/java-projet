package com.ism.gestioncours;

import com.ism.gestioncours.entities.Cours;
import com.ism.gestioncours.entities.Module; // Assurez-vous d'importer la bonne classe
import com.ism.gestioncours.repository.CoursRepository;
import com.ism.gestioncours.repository.CoursRepositoryImpl;
import com.ism.gestioncours.repository.ModuleRepository;
import com.ism.gestioncours.repository.ModuleRepositoryImpl;
import com.ism.gestioncours.service.CoursService;
import com.ism.gestioncours.service.ModuleService;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final String URL = "jdbc:mysql://localhost:3306/gestion_cours";
    private static final String USER = "root";
    private static final String PASSWORD = "password";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            ModuleRepository moduleRepository = new ModuleRepositoryImpl(connection);
            CoursRepository coursRepository = new CoursRepositoryImpl(connection);

            ModuleService moduleService = new ModuleService(moduleRepository);
            CoursService coursService = new CoursService(coursRepository);

            Scanner scanner = new Scanner(System.in);
            boolean running = true;

            while (running) {
                System.out.println("1. Ajouter un Module");
                System.out.println("2. Lister les Modules");
                System.out.println("3. Créer un cours");
                System.out.println("4. Lister tous les cours");
                System.out.println("5. Lister les cours d’un module et d’un professeur");
                System.out.println("6. Quitter");
                System.out.print("Choisissez une option: ");
                int choice = scanner.nextInt();
                scanner.nextLine();  // Consomme la nouvelle ligne

                switch (choice) {
                    case 1:
                        System.out.print("Entrez le nom du module: ");
                        String moduleName = scanner.nextLine();
                        moduleService.addModule(moduleName);
                        System.out.println("Module ajouté avec succès !");
                        break;
                    case 2:
                        List<Module> modules = moduleService.listModules();
                        for (Module module : modules) {
                            System.out.println("ID: " + module.getId() + ", Nom: " + module.getNom());
                        }
                        break;
                    case 3:
                        System.out.print("Entrez la date du cours (AAAA-MM-JJ): ");
                        LocalDate date = LocalDate.parse(scanner.nextLine());
                        System.out.print("Entrez l'heure de début du cours (HH:MM): ");
                        LocalTime heureDb = LocalTime.parse(scanner.nextLine());
                        System.out.print("Entrez l'heure de fin du cours (HH:MM): ");
                        LocalTime heureFin = LocalTime.parse(scanner.nextLine());
                        System.out.print("Entrez l'ID du professeur: ");
                        int professeurId = scanner.nextInt();
                        System.out.print("Entrez l'ID du module: ");
                        int moduleId = scanner.nextInt();
                        scanner.nextLine();  // Consomme la nouvelle ligne
                        coursService.createCours(date, heureDb, heureFin, professeurId, moduleId);
                        System.out.println("Cours créé avec succès !");
                        break;
                    case 4:
                        List<Cours> coursList = coursService.listAllCours();
                        for (Cours cours : coursList) {
                            System.out.println("ID: " + cours.getId() + ", Date: " + cours.getDate() + ", Heure début: " + cours.getHeureDb() + ", Heure fin: " + cours.getHeureFin() +
                                    ", Professeur: " + cours.getProfesseur().getNom() + " " + cours.getProfesseur().getPrenom() + ", Module: " + cours.getModule().getNom());
                        }
                        break;
                    case 5:
                        System.out.print("Entrez l'ID du module: ");
                        int modId = scanner.nextInt();
                        System.out.print("Entrez l'ID du professeur: ");
                        int profId = scanner.nextInt();
                        scanner.nextLine();  // Consomme la nouvelle ligne
                        List<Cours> coursListByModuleAndProfesseur = coursService.listCoursByModuleAndProfesseur(modId, profId);
                        for (Cours cours : coursListByModuleAndProfesseur) {
                            System.out.println("ID: " + cours.getId() + ", Date: " + cours.getDate() + ", Heure début: " + cours.getHeureDb() + ", Heure fin: " + cours.getHeureFin() +
                                    ", Professeur: " + cours.getProfesseur().getNom() + " " + cours.getProfesseur().getPrenom() + ", Module: " + cours.getModule().getNom());
                        }
                        break;
                    case 6:
                        running = false;
                        break;
                    default:
                        System.out.println("Option non valide. Veuillez réessayer.");
                }
            }

            scanner.close();
        } catch (SQLException e) {
            System.out.println("Erreur de connexion à la base de données : " + e.getMessage());
        }
    }
}
